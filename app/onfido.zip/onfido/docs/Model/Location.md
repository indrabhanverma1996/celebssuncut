# # Location

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ip_address** | **string** | The applicant&#39;s ip address | [optional]
**country_of_residence** | **string** | The applicant&#39;s country of residence | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
