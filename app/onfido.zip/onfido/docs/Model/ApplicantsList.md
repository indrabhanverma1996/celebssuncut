# # ApplicantsList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applicants** | [**\Onfido\Model\ApplicantResponse[]**](ApplicantResponse.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
